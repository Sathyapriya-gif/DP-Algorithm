
    document.getElementById('problemType').addEventListener('change', function () {
      document.getElementById('valuesDiv').style.display = this.value === 'knapsack' ? 'block' : 'none';
    });

    function toggleDarkMode() {
      document.body.classList.toggle('dark');
    }

    function generateRandom() {
      const diff = document.getElementById('difficulty').value;
      let size = diff === 'easy' ? 4 : diff === 'medium' ? 6 : 8;
      let weights = Array.from({ length: size }, () => Math.floor(Math.random() * 10) + 1);
      document.getElementById('weights').value = weights.join(',');

      if (document.getElementById('problemType').value === 'knapsack') {
        let values = Array.from({ length: size }, () => Math.floor(Math.random() * 20) + 1);
        document.getElementById('values').value = values.join(',');
      }

      let cap = Math.floor(weights.reduce((a, b) => a + b) / 2);
      document.getElementById('capacity').value = cap;
    }

    async function solve(animate = false) {
      const mode = document.querySelector('input[name="mode"]:checked').value;
      const type = document.getElementById('problemType').value;
      const weights = document.getElementById('weights').value.split(',').map(Number);
      const cap = parseInt(document.getElementById('capacity').value);
      const result = document.getElementById('result');
      result.innerHTML = "";

      if (type === 'subset') {
        const { dp, steps } = subsetSumDP(weights, cap);
        displayDP(dp, "Subset Sum DP Table", result);
        if (animate) await animateDPTable(steps);
        const subset = traceSubset(weights, dp, cap);
        const answer = dp[weights.length][cap];

        if (mode === 'game') {
          result.innerHTML += `
            <p><strong>🎲 Game Mode:</strong> Does a subset with sum ${cap} exist?</p>
            <button onclick="checkGuess(true, ${answer})">Yes</button>
            <button onclick="checkGuess(false, ${answer})">No</button>
          `;
        } else {
          result.innerHTML += `<p><strong>Subset with sum ${cap} ${answer ? "exists" : "does not exist"}.</strong></p>`;
          if (subset.length > 0) {
            result.innerHTML += `<p><strong>Subset:</strong> [${subset.join(', ')}]</p>`;
          }
        }

      } else {
        const values = document.getElementById('values').value.split(',').map(Number);
        if (values.length !== weights.length) {
          result.innerHTML = "<p style='color:red;'>Weights and values length must match.</p>";
          return;
        }

        const { dp, steps } = knapsackDP(weights, values, cap);
        displayDP(dp, "Knapsack DP Table", result);
        if (animate) await animateDPTable(steps);
        const includedItems = traceKnapsack(weights, values, dp, cap);
        const maxVal = dp[weights.length][cap];

        if (mode === 'game') {
          result.innerHTML += `
            <p><strong>🎲 Game Mode:</strong> Guess the maximum value for capacity ${cap}</p>
            <input type="number" id="guessVal" placeholder="Your guess" />
            <button onclick="checkKnapsackGuess(${maxVal}, [${includedItems}])">Check</button>
          `;
        } else {
          result.innerHTML += `<p><strong>Maximum value for capacity ${cap}: ${maxVal}</strong></p>`;
          result.innerHTML += `<p><strong>Included items (0-based):</strong> [${includedItems.join(', ')}]</p>`;
        }
      }
    }

    function subsetSumDP(arr, sum) {
      const n = arr.length;
      const dp = Array.from({ length: n + 1 }, () => Array(sum + 1).fill(false));
      const steps = [];
      for (let i = 0; i <= n; i++) dp[i][0] = true;

      for (let i = 1; i <= n; i++) {
        for (let j = 1; j <= sum; j++) {
          dp[i][j] = arr[i - 1] > j ? dp[i - 1][j] : (dp[i - 1][j] || dp[i - 1][j - arr[i - 1]]);
          steps.push({ i, j, value: dp[i][j] });
        }
      }
      return { dp, steps };
    }

    function knapsackDP(wt, val, W) {
      const n = wt.length;
      const dp = Array.from({ length: n + 1 }, () => Array(W + 1).fill(0));
      const steps = [];
      for (let i = 1; i <= n; i++) {
        for (let w = 0; w <= W; w++) {
          dp[i][w] = wt[i - 1] <= w
            ? Math.max(dp[i - 1][w], val[i - 1] + dp[i - 1][w - wt[i - 1]])
            : dp[i - 1][w];
          steps.push({ i, j: w, value: dp[i][w] });
        }
      }
      return { dp, steps };
    }

    function traceSubset(arr, dp, sum) {
      let res = [], i = arr.length, j = sum;
      while (i > 0 && j >= 0) {
        if (dp[i][j] && !dp[i - 1][j]) {
          res.push(arr[i - 1]);
          j -= arr[i - 1];
        }
        i--;
      }
      return dp[arr.length][sum] ? res.reverse() : [];
    }

    function traceKnapsack(weights, values, dp, capacity) {
      let i = weights.length, w = capacity, items = [];
      while (i > 0 && w > 0) {
        if (dp[i][w] !== dp[i - 1][w]) {
          items.push(i - 1);
          w -= weights[i - 1];
        }
        i--;
      }
      return items.reverse();
    }

    function displayDP(dp, title, container) {
      let html = `<h2>${title}</h2><table id="dpTable"><tr><th>I\\W</th>`;
      for (let j = 0; j < dp[0].length; j++) html += `<th>${j}</th>`;
      html += "</tr>";
      for (let i = 0; i < dp.length; i++) {
        html += `<tr><th>${i}</th>`;
        for (let j = 0; j < dp[0].length; j++) {
          html += `<td id="cell-${i}-${j}">${dp[i][j]}</td>`;
        }
        html += "</tr>";
      }
      html += "</table>";
      container.innerHTML += html;
    }

    async function animateDPTable(steps) {
      for (const step of steps) {
        const cell = document.getElementById(`cell-${step.i}-${step.j}`);
        if (cell) {
          cell.classList.add("highlight");
          await new Promise(resolve => setTimeout(resolve, 30));
        }
      }
    }

    function checkGuess(userGuess, correct) {
      alert(userGuess === Boolean(correct) ? "✅ Correct!" : "❌ Nope, try again!");
    }

    function checkKnapsackGuess(correctValue, included) {
      const userVal = parseInt(document.getElementById('guessVal').value);
      alert(userVal === correctValue
        ? `✅ Correct! Included items: [${included.join(', ')}]`
        : `❌ Incorrect! Correct value: ${correctValue}`);
    }

    function exportSolution() {
      const mode = document.querySelector('input[name="mode"]:checked').value;
      const type = document.getElementById('problemType').value;
      const cap = parseInt(document.getElementById('capacity').value);
      const weights = document.getElementById('weights').value.split(',').map(Number);
      const resultObj = { mode, type, capacity: cap, weights };

      if (type === 'knapsack') {
        const values = document.getElementById('values').value.split(',').map(Number);
        const { dp } = knapsackDP(weights, values, cap);
        const includedItems = traceKnapsack(weights, values, dp, cap);
        resultObj.values = values;
        resultObj.maxValue = dp[weights.length][cap];
        resultObj.includedItems = includedItems;
        resultObj.dpTable = dp;
      } else {
        const { dp } = subsetSumDP(weights, cap);
        const subset = traceSubset(weights, dp, cap);
        resultObj.subsetExists = dp[weights.length][cap];
        resultObj.subset = subset;
        resultObj.dpTable = dp;
      }

      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(resultObj, null, 2));
      const dl = document.createElement('a');
      dl.setAttribute("href", dataStr);
      dl.setAttribute("download", `${type}_solution.json`);
      dl.click();
      
      
document.getElementById("problemType").addEventListener("change", function () {
  const problem = this.value;
  document.getElementById("valuesDiv").style.display = (problem === "knapsack") ? "block" : "none";
  document.getElementById("commonInputs").style.display = (problem !== "obst") ? "block" : "none";
  document.getElementById("obstDiv").style.display = (problem === "obst") ? "block" : "none";
});

function solve(animate = false) {
  const problemType = document.getElementById("problemType").value;
  if (problemType === "knapsack") {
    solveKnapsack();
  }
  // Handle other cases like 'subset' or 'obst'...
}

function solveKnapsack() {
  const weights = document.getElementById("weights").value.split(",").map(Number);
  const values = document.getElementById("values").value.split(",").map(Number);
  const capacity = parseInt(document.getElementById("capacity").value);

  if (weights.length !== values.length) {
    alert("Weights and Values must be the same length.");
    return;
  }

  const n = weights.length;
  const memo = Array.from({ length: n + 1 }, () => Array(capacity + 1).fill(-1));

  function knapsack(i, w) {
    if (i === 0 || w === 0) return 0;
    if (memo[i][w] !== -1) return memo[i][w];

    if (weights[i - 1] > w) {
      memo[i][w] = knapsack(i - 1, w);
    } else {
      memo[i][w] = Math.max(
        knapsack(i - 1, w),
        values[i - 1] + knapsack(i - 1, w - weights[i - 1])
      );
    }
    return memo[i][w];
  }

  const result = knapsack(n, capacity);
  document.getElementById("result").innerHTML = `<h3>Max Value: ${result}</h3>`;
}


    }

